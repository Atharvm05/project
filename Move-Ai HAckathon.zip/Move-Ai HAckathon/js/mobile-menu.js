// Mobile Menu Implementation

document.addEventListener('DOMContentLoaded', function() {
    initMobileMenu();
});

function initMobileMenu() {
    const nav = document.querySelector('nav');
    const navLinks = document.querySelector('.hidden.md\\:flex');
    
    // Create mobile menu button
    const mobileMenuButton = document.createElement('button');
    mobileMenuButton.className = 'md:hidden p-2 rounded-lg text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700';
    mobileMenuButton.innerHTML = '<i class="fas fa-bars text-xl"></i>';
    mobileMenuButton.setAttribute('aria-label', 'Toggle mobile menu');
    
    // Insert mobile menu button before the theme toggle button
    const themeToggle = document.getElementById('theme-toggle');
    themeToggle.parentNode.insertBefore(mobileMenuButton, themeToggle);
    
    // Create mobile menu container
    const mobileMenu = document.createElement('div');
    mobileMenu.className = 'mobile-nav';
    mobileMenu.innerHTML = `
        <div class="p-4 flex justify-between items-center border-b border-gray-200 dark:border-gray-700">
            <div class="flex items-center">
                <img src="images/logo.svg" alt="Aptos AI Nexus Logo" class="h-10 mr-3">
                <h1 class="text-xl font-bold text-indigo-600 dark:text-indigo-400">Aptos AI Nexus</h1>
            </div>
            <button class="close-menu p-2 rounded-lg text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700">
                <i class="fas fa-times text-xl"></i>
            </button>
        </div>
        <div class="p-4">
            <div class="flex flex-col space-y-4">
                <!-- Mobile menu links will be inserted here -->
            </div>
        </div>
    `;
    
    // Add mobile menu to the body
    document.body.appendChild(mobileMenu);
    
    // Clone navigation links for mobile menu
    const mobileMenuLinks = mobileMenu.querySelector('.flex.flex-col');
    const navLinksClone = navLinks.cloneNode(true);
    const links = navLinksClone.querySelectorAll('a');
    
    links.forEach(link => {
        // Create new div for each link
        const linkContainer = document.createElement('div');
        linkContainer.className = 'py-2 border-b border-gray-200 dark:border-gray-700';
        
        // Clone the link and adjust its classes
        const newLink = link.cloneNode(true);
        newLink.className = 'block text-lg text-gray-700 dark:text-gray-300 hover:text-indigo-600 dark:hover:text-indigo-400';
        
        linkContainer.appendChild(newLink);
        mobileMenuLinks.appendChild(linkContainer);
    });
    
    // Toggle mobile menu
    mobileMenuButton.addEventListener('click', function() {
        mobileMenu.classList.add('open');
        document.body.style.overflow = 'hidden'; // Prevent scrolling when menu is open
    });
    
    // Close mobile menu
    const closeButton = mobileMenu.querySelector('.close-menu');
    closeButton.addEventListener('click', function() {
        mobileMenu.classList.remove('open');
        document.body.style.overflow = ''; // Restore scrolling
    });
    
    // Close mobile menu when clicking on a link
    mobileMenuLinks.querySelectorAll('a').forEach(link => {
        link.addEventListener('click', function() {
            mobileMenu.classList.remove('open');
            document.body.style.overflow = ''; // Restore scrolling
        });
    });
    
    // Close mobile menu when clicking outside
    document.addEventListener('click', function(event) {
        if (!mobileMenu.contains(event.target) && event.target !== mobileMenuButton) {
            mobileMenu.classList.remove('open');
            document.body.style.overflow = ''; // Restore scrolling
        }
    });
}