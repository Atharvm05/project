// Wallet UI Components and Interactions

document.addEventListener('DOMContentLoaded', function() {
    initWalletUI();
    initThemeToggle(); // Ensure this function is called
});

function initWalletUI() {
    // Initialize wallet connection
    initWalletConnection();
    
    // Add transaction modal to the page
    addTransactionModal();
    
    // Add wallet dashboard modal
    addWalletDashboardModal();
}

// Create wallet info display
function createWalletInfoDisplay(walletData) {
    // Remove existing wallet info if present
    const existingWalletInfo = document.getElementById('wallet-info');
    if (existingWalletInfo) {
        existingWalletInfo.remove();
    }
    
    // Create wallet info container
    const walletInfo = document.createElement('div');
    walletInfo.id = 'wallet-info';
    walletInfo.className = 'fixed top-20 right-4 bg-white dark:bg-gray-800 rounded-lg shadow-lg p-4 z-50 w-80';
    
    // Create wallet info content
    walletInfo.innerHTML = `
        <div class="flex justify-between items-center mb-3">
            <h3 class="text-lg font-semibold text-gray-800 dark:text-white">Wallet Info</h3>
            <button class="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <div class="mb-3 pb-3 border-b border-gray-200 dark:border-gray-700">
            <div class="flex items-center mb-2">
                <div class="w-8 h-8 rounded-full bg-indigo-100 dark:bg-indigo-900 flex items-center justify-center mr-3">
                    <i class="fas fa-wallet text-indigo-600 dark:text-indigo-400"></i>
                </div>
                <div>
                    <p class="text-sm text-gray-500 dark:text-gray-400">Connected with ${walletData.walletType}</p>
                    <p class="text-sm font-medium text-gray-800 dark:text-white">${walletData.address.substring(0, 8)}...${walletData.address.substring(walletData.address.length - 8)}</p>
                </div>
            </div>
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm text-gray-500 dark:text-gray-400">Balance</p>
                    <p class="text-lg font-semibold text-gray-800 dark:text-white">${walletData.balance.toFixed(2)} APT</p>
                </div>
                <div>
                    <p class="text-sm text-gray-500 dark:text-gray-400">Network</p>
                    <p class="text-sm font-medium text-gray-800 dark:text-white capitalize">${walletData.network}</p>
                </div>
            </div>
        </div>
        <div class="flex space-x-2">
            <button id="wallet-send" class="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white px-3 py-2 rounded-lg text-sm transition">
                <i class="fas fa-paper-plane mr-1"></i> Send
            </button>
            <button id="wallet-receive" class="flex-1 bg-green-600 hover:bg-green-700 text-white px-3 py-2 rounded-lg text-sm transition">
                <i class="fas fa-qrcode mr-1"></i> Receive
            </button>
            <button id="wallet-dashboard" class="flex-1 bg-gray-200 hover:bg-gray-300 dark:bg-gray-700 dark:hover:bg-gray-600 text-gray-800 dark:text-white px-3 py-2 rounded-lg text-sm transition">
                <i class="fas fa-chart-line mr-1"></i> Dashboard
            </button>
        </div>
    `;
    
    // Add to body
    document.body.appendChild(walletInfo);
    
    // Add event listeners
    const closeButton = walletInfo.querySelector('button');
    closeButton.addEventListener('click', function() {
        walletInfo.remove();
    });
    
    // Send button
    const sendButton = document.getElementById('wallet-send');
    sendButton.addEventListener('click', function() {
        showTransactionModal('send');
    });
    
    // Receive button
    const receiveButton = document.getElementById('wallet-receive');
    receiveButton.addEventListener('click', function() {
        showReceiveModal();
    });
    
    // Dashboard button
    const dashboardButton = document.getElementById('wallet-dashboard');
    dashboardButton.addEventListener('click', function() {
        showDashboardModal();
    });
}

function showReceiveModal() {
    const modal = document.createElement('div');
    modal.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
    modal.innerHTML = `
        <div class="bg-white dark:bg-gray-800 rounded-lg p-6 w-96 max-w-full mx-4">
            <div class="flex justify-between items-center mb-4">
                <h3 class="text-lg font-semibold text-gray-800 dark:text-white">Receive APT</h3>
                <button class="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="text-center mb-4">
                <div class="bg-gray-100 dark:bg-gray-700 p-4 rounded-lg mb-4">
                    <canvas id="qr-code" class="mx-auto"></canvas>
                </div>
                <p class="text-sm text-gray-600 dark:text-gray-400 mb-2">Your Wallet Address</p>
                <p class="text-xs bg-gray-100 dark:bg-gray-700 p-2 rounded break-all">${wallet.address}</p>
            </div>
            <div class="flex justify-center">
                <button class="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg text-sm transition" onclick="copyToClipboard('${wallet.address}')">
                    <i class="fas fa-copy mr-1"></i> Copy Address
                </button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Close modal on click outside or close button
    modal.addEventListener('click', function(e) {
        if (e.target === modal || e.target.closest('button')) {
            modal.remove();
        }
    });
    
    // Generate QR code
    generateQRCode(wallet.address);
}

function showDashboardModal() {
    const modal = document.createElement('div');
    modal.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
    modal.innerHTML = `
        <div class="bg-white dark:bg-gray-800 rounded-lg p-6 w-full max-w-4xl mx-4 max-h-[90vh] overflow-y-auto">
            <div class="flex justify-between items-center mb-6">
                <h3 class="text-xl font-semibold text-gray-800 dark:text-white">Wallet Dashboard</h3>
                <button class="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div class="bg-gray-100 dark:bg-gray-700 p-4 rounded-lg">
                    <h4 class="text-lg font-medium text-gray-800 dark:text-white mb-2">Balance</h4>
                    <p class="text-2xl font-bold text-indigo-600 dark:text-indigo-400">${wallet.balance.toFixed(2)} APT</p>
                </div>
                <div class="bg-gray-100 dark:bg-gray-700 p-4 rounded-lg">
                    <h4 class="text-lg font-medium text-gray-800 dark:text-white mb-2">Network</h4>
                    <p class="text-lg text-gray-600 dark:text-gray-300 capitalize">${wallet.network}</p>
                </div>
            </div>
            <div class="mb-6">
                <h4 class="text-lg font-medium text-gray-800 dark:text-white mb-4">Transaction History</h4>
                <div class="space-y-4">
                    ${generateTransactionHistory()}
                </div>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Close modal on click outside or close button
    modal.addEventListener('click', function(e) {
        if (e.target === modal || e.target.closest('button')) {
            modal.remove();
        }
    });
}

function generateTransactionHistory() {
    if (!wallet.transactions || wallet.transactions.length === 0) {
        return '<p class="text-center text-gray-500 dark:text-gray-400">No transactions found</p>';
    }
    
    return wallet.transactions.map(tx => `
        <div class="bg-white dark:bg-gray-700 p-4 rounded-lg shadow">
            <div class="flex justify-between items-center mb-2">
                <span class="${tx.type === 'send' ? 'text-red-500' : 'text-green-500'} font-medium">
                    ${tx.type === 'send' ? 'Sent' : 'Received'} APT
                </span>
                <span class="text-sm text-gray-500 dark:text-gray-400">${new Date(tx.timestamp).toLocaleString()}</span>
            </div>
            <p class="text-sm text-gray-600 dark:text-gray-300 mb-2">
                ${tx.type === 'send' ? 'To' : 'From'}: ${tx.address.substring(0, 8)}...${tx.address.substring(tx.address.length - 8)}
            </p>
            <div class="flex justify-between items-center">
                <span class="text-lg font-semibold text-gray-800 dark:text-white">${tx.amount} APT</span>
                <a href="https://explorer.aptoslabs.com/txn/${tx.hash}" target="_blank" class="text-indigo-600 hover:text-indigo-700 dark:text-indigo-400 dark:hover:text-indigo-300 text-sm">
                    View on Explorer <i class="fas fa-external-link-alt ml-1"></i>
                </a>
            </div>
        </div>
    `).join('');
}

function generateQRCode(address) {
    const qr = new QRCode(document.getElementById('qr-code'), {
        text: address,
        width: 200,
        height: 200,
        colorDark: '#000000',
        colorLight: '#ffffff',
        correctLevel: QRCode.CorrectLevel.H
    });
}

function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        // Show success message
        const button = document.querySelector('button:contains("Copy Address")');
        const originalText = button.innerHTML;
        button.innerHTML = '<i class="fas fa-check mr-1"></i> Copied!';
        setTimeout(() => {
            button.innerHTML = originalText;
        }, 2000);
    }).catch(err => {
        console.error('Failed to copy text: ', err);
    });
}


function initThemeToggle() {
    // Listen for theme changes from main.js
    window.addEventListener('themeChange', (e) => {
        const isDark = e.detail.isDark;
        updateWalletUITheme(isDark);
    });
    
    // Initial theme setup
    const isDark = document.documentElement.classList.contains('dark');
    updateWalletUITheme(isDark);
}

function updateWalletUITheme(isDark) {
    // Update wallet info display if it exists
    const walletInfo = document.getElementById('wallet-info');
    if (walletInfo) {
        walletInfo.className = `fixed top-20 right-4 ${isDark ? 'dark' : ''} bg-white dark:bg-gray-800 rounded-lg shadow-lg p-4 z-50 w-80`;
    }
    
    // Update modals if they exist
    const modals = document.querySelectorAll('.modal-content');
    modals.forEach(modal => {
        modal.className = `bg-white dark:bg-gray-800 rounded-lg p-6 ${isDark ? 'dark' : ''}`;
    });
    
    // Update buttons
    const buttons = document.querySelectorAll('.theme-aware-button');
    buttons.forEach(button => {
        button.className = button.className.replace(/bg-\w+-\d+/g, isDark ? 'bg-gray-700' : 'bg-gray-200');
    });
}