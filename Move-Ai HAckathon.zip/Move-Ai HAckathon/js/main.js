// Aptos AI Nexus - Main JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Initialize Dark Mode
    initDarkMode();
    
    // Initialize Charts
    initCharts();
    
    // Initialize Agent Network Visualization
    initAgentNetwork();
    
    // Initialize Game Demo
    initGameDemo();
});

// Dark Mode Toggle with Enhanced Theme Management
function initDarkMode() {
    const themeToggle = document.getElementById('theme-toggle');
    const root = document.documentElement;
    const body = document.body;
    
    // Function to update theme
    function updateTheme(isDark) {
        if (isDark) {
            root.classList.add('dark');
            body.classList.add('dark');
            localStorage.setItem('color-theme', 'dark');
            themeToggle.setAttribute('aria-label', 'Switch to light mode');
            themeToggle.innerHTML = '<i class="fas fa-sun text-yellow-300"></i>';
        } else {
            root.classList.remove('dark');
            body.classList.remove('dark');
            localStorage.setItem('color-theme', 'light');
            themeToggle.setAttribute('aria-label', 'Switch to dark mode');
            themeToggle.innerHTML = '<i class="fas fa-moon"></i>';
        }
        
        // Dispatch event for other components
        window.dispatchEvent(new CustomEvent('themeChange', { detail: { isDark } }));
        
        // Force update all themed elements
        document.querySelectorAll('[class*="dark:"]').forEach(el => {
            el.classList.remove('dark');
            if (isDark) el.classList.add('dark');
        });
    }
    
    // Check for saved theme preference or use system preference
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)');
    const savedTheme = localStorage.getItem('color-theme');
    
    // Initialize theme
    updateTheme(savedTheme === 'dark' || (!savedTheme && prefersDark.matches));
    
    // Toggle theme on button click
    themeToggle.addEventListener('click', () => {
        updateTheme(!root.classList.contains('dark'));
    });
    
    // Listen for system theme changes
    prefersDark.addEventListener('change', (e) => {
        if (!localStorage.getItem('color-theme')) {
            updateTheme(e.matches);
        }
    });
}

// Initialize Charts
function initCharts() {
    // DeFi Portfolio Performance Chart
    const defiCtx = document.getElementById('defiChart');
    if (defiCtx) {
        new Chart(defiCtx, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep'],
                datasets: [
                    {
                        label: 'Portfolio Value (USD)',
                        data: [5000, 5800, 5600, 6200, 7500, 7200, 8400, 9100, 10500],
                        borderColor: '#6366f1',
                        backgroundColor: 'rgba(99, 102, 241, 0.1)',
                        tension: 0.4,
                        fill: true
                    },
                    {
                        label: 'Benchmark Index',
                        data: [5000, 5200, 5300, 5600, 5900, 6100, 6400, 6800, 7200],
                        borderColor: '#a855f7',
                        backgroundColor: 'rgba(168, 85, 247, 0.0)',
                        tension: 0.4,
                        borderDash: [5, 5]
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top',
                        labels: {
                            color: document.documentElement.classList.contains('dark') ? '#f3f4f6' : '#1f2937'
                        }
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false
                    }
                },
                scales: {
                    x: {
                        grid: {
                            color: document.documentElement.classList.contains('dark') ? 'rgba(243, 244, 246, 0.1)' : 'rgba(31, 41, 55, 0.1)'
                        },
                        ticks: {
                            color: document.documentElement.classList.contains('dark') ? '#f3f4f6' : '#1f2937'
                        }
                    },
                    y: {
                        grid: {
                            color: document.documentElement.classList.contains('dark') ? 'rgba(243, 244, 246, 0.1)' : 'rgba(31, 41, 55, 0.1)'
                        },
                        ticks: {
                            color: document.documentElement.classList.contains('dark') ? '#f3f4f6' : '#1f2937',
                            callback: function(value) {
                                return '$' + value.toLocaleString();
                            }
                        }
                    }
                }
            }
        });
    }
    
    // Social Sentiment Chart
    const sentimentCtx = document.getElementById('sentimentChart');
    if (sentimentCtx) {
        new Chart(sentimentCtx, {
            type: 'radar',
            data: {
                labels: ['Twitter', 'Discord', 'Reddit', 'Telegram', 'Medium', 'GitHub'],
                datasets: [{
                    label: 'Current Sentiment',
                    data: [85, 75, 70, 80, 65, 90],
                    backgroundColor: 'rgba(59, 130, 246, 0.2)',
                    borderColor: '#3b82f6',
                    borderWidth: 2,
                    pointBackgroundColor: '#3b82f6',
                    pointBorderColor: '#fff',
                    pointHoverBackgroundColor: '#fff',
                    pointHoverBorderColor: '#3b82f6'
                }, {
                    label: 'Last Week Sentiment',
                    data: [75, 65, 60, 70, 60, 80],
                    backgroundColor: 'rgba(168, 85, 247, 0.2)',
                    borderColor: '#a855f7',
                    borderWidth: 2,
                    pointBackgroundColor: '#a855f7',
                    pointBorderColor: '#fff',
                    pointHoverBackgroundColor: '#fff',
                    pointHoverBorderColor: '#a855f7'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    r: {
                        angleLines: {
                            color: document.documentElement.classList.contains('dark') ? 'rgba(243, 244, 246, 0.1)' : 'rgba(31, 41, 55, 0.1)'
                        },
                        grid: {
                            color: document.documentElement.classList.contains('dark') ? 'rgba(243, 244, 246, 0.1)' : 'rgba(31, 41, 55, 0.1)'
                        },
                        pointLabels: {
                            color: document.documentElement.classList.contains('dark') ? '#f3f4f6' : '#1f2937'
                        },
                        ticks: {
                            color: document.documentElement.classList.contains('dark') ? '#f3f4f6' : '#1f2937',
                            backdropColor: 'transparent'
                        }
                    }
                },
                plugins: {
                    legend: {
                        position: 'top',
                        labels: {
                            color: document.documentElement.classList.contains('dark') ? '#f3f4f6' : '#1f2937'
                        }
                    }
                }
            }
        });
    }
    
    // NPC Evolution Chart
    const npcEvolutionCtx = document.getElementById('npcEvolutionChart');
    if (npcEvolutionCtx) {
        new Chart(npcEvolutionCtx, {
            type: 'bar',
            data: {
                labels: ['Intelligence', 'Adaptability', 'Creativity', 'Social Skills', 'Combat Skills'],
                datasets: [{
                    label: 'Current Generation',
                    data: [85, 92, 78, 65, 88],
                    backgroundColor: '#6366f1'
                }, {
                    label: 'Previous Generation',
                    data: [70, 75, 60, 55, 80],
                    backgroundColor: '#a855f7'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: {
                        grid: {
                            color: document.documentElement.classList.contains('dark') ? 'rgba(243, 244, 246, 0.1)' : 'rgba(31, 41, 55, 0.1)'
                        },
                        ticks: {
                            color: document.documentElement.classList.contains('dark') ? '#f3f4f6' : '#1f2937'
                        }
                    },
                    y: {
                        grid: {
                            color: document.documentElement.classList.contains('dark') ? 'rgba(243, 244, 246, 0.1)' : 'rgba(31, 41, 55, 0.1)'
                        },
                        ticks: {
                            color: document.documentElement.classList.contains('dark') ? '#f3f4f6' : '#1f2937'
                        },
                        max: 100
                    }
                },
                plugins: {
                    legend: {
                        position: 'top',
                        labels: {
                            color: document.documentElement.classList.contains('dark') ? '#f3f4f6' : '#1f2937'
                        }
                    }
                }
            }
        });
    }
    
    // Governance Chart
    const governanceCtx = document.getElementById('governanceChart');
    if (governanceCtx) {
        new Chart(governanceCtx, {
            type: 'doughnut',
            data: {
                labels: ['AI-Driven Proposals', 'Community Proposals', 'Foundation Proposals', 'Developer Proposals'],
                datasets: [{
                    data: [40, 30, 15, 15],
                    backgroundColor: ['#6366f1', '#3b82f6', '#a855f7', '#22c55e'],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '70%',
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            color: document.documentElement.classList.contains('dark') ? '#f3f4f6' : '#1f2937',
                            padding: 20,
                            usePointStyle: true,
                            pointStyle: 'circle'
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return `${context.label}: ${context.raw}%`;
                            }
                        }
                    }
                }
            }
        });
    }
}

// Initialize Agent Network Visualization
function initAgentNetwork() {
    const agentNetwork = document.getElementById('agentNetwork');
    if (!agentNetwork) return;
    
    // Simple SVG-based network visualization
    const isDark = document.documentElement.classList.contains('dark');
    const textColor = isDark ? '#f3f4f6' : '#1f2937';
    const bgColor = isDark ? '#374151' : '#f3f4f6';
    const lineColor = isDark ? 'rgba(243, 244, 246, 0.2)' : 'rgba(31, 41, 55, 0.2)';
    
    const width = agentNetwork.clientWidth;
    const height = agentNetwork.clientHeight;
    
    // Create SVG
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('width', '100%');
    svg.setAttribute('height', '100%');
    svg.setAttribute('viewBox', `0 0 ${width} ${height}`);
    agentNetwork.appendChild(svg);
    
    // Define nodes
    const nodes = [
        { id: 'central', label: 'AI Nexus', x: width / 2, y: height / 2, color: '#6366f1', size: 30 },
        { id: 'defi', label: 'DeFi Agent', x: width * 0.25, y: height * 0.3, color: '#22c55e', size: 20 },
        { id: 'social', label: 'Social Agent', x: width * 0.75, y: height * 0.3, color: '#3b82f6', size: 20 },
        { id: 'gamefi', label: 'GameFi Agent', x: width * 0.25, y: height * 0.7, color: '#a855f7', size: 20 },
        { id: 'agentic', label: 'Agentic Infra', x: width * 0.75, y: height * 0.7, color: '#eab308', size: 20 }
    ];
    
    // Define links
    const links = [
        { source: 'central', target: 'defi' },
        { source: 'central', target: 'social' },
        { source: 'central', target: 'gamefi' },
        { source: 'central', target: 'agentic' },
        { source: 'defi', target: 'social' },
        { source: 'social', target: 'agentic' },
        { source: 'agentic', target: 'gamefi' },
        { source: 'gamefi', target: 'defi' }
    ];
    
    // Draw links
    links.forEach(link => {
        const source = nodes.find(n => n.id === link.source);
        const target = nodes.find(n => n.id === link.target);
        
        const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
        line.setAttribute('x1', source.x);
        line.setAttribute('y1', source.y);
        line.setAttribute('x2', target.x);
        line.setAttribute('y2', target.y);
        line.setAttribute('stroke', lineColor);
        line.setAttribute('stroke-width', '2');
        line.setAttribute('stroke-dasharray', '5,5');
        line.classList.add('link-dash');
        svg.appendChild(line);
        
        // Animate data flow
        const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        circle.setAttribute('r', '3');
        circle.setAttribute('fill', source.color);
        
        // Create animation
        const animateMotion = document.createElementNS('http://www.w3.org/2000/svg', 'animateMotion');
        animateMotion.setAttribute('dur', `${3 + Math.random() * 2}s`);
        animateMotion.setAttribute('repeatCount', 'indefinite');
        animateMotion.setAttribute('path', `M${source.x},${source.y} L${target.x},${target.y}`);
        
        circle.appendChild(animateMotion);
        svg.appendChild(circle);
    });
    
    // Draw nodes
    nodes.forEach(node => {
        // Node circle
        const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        circle.setAttribute('cx', node.x);
        circle.setAttribute('cy', node.y);
        circle.setAttribute('r', node.size);
        circle.setAttribute('fill', node.color);
        if (node.id !== 'central') {
            circle.classList.add('node-pulse');
        }
        svg.appendChild(circle);
        
        // Node label
        const text = document.createElementNS('http://www.w3.org/2000/svg', 'text');
        text.setAttribute('x', node.x);
        text.setAttribute('y', node.y + node.size + 15);
        text.setAttribute('text-anchor', 'middle');
        text.setAttribute('fill', textColor);
        text.setAttribute('font-size', '12');
        text.textContent = node.label;
        svg.appendChild(text);
    });
}

// Initialize Game Demo
function initGameDemo() {
    const gameDemo = document.getElementById('gameDemo');
    if (!gameDemo) return;
    
    // Create canvas for game demo
    const canvas = document.createElement('canvas');
    canvas.width = gameDemo.clientWidth;
    canvas.height = gameDemo.clientHeight;
    gameDemo.appendChild(canvas);
    
    const ctx = canvas.getContext('2d');
    const isDark = document.documentElement.classList.contains('dark');
    
    // Game state
    const state = {
        player: { x: 50, y: canvas.height / 2, size: 15, color: '#6366f1', speed: 3, tokens: 0 },
        npcs: [],
        tokens: [],
        obstacles: [],
        frame: 0
    };
    
    // Create NPCs
    for (let i = 0; i < 5; i++) {
        state.npcs.push({
            x: Math.random() * canvas.width,
            y: Math.random() * canvas.height,
            size: 12,
            color: '#a855f7',
            speedX: (Math.random() - 0.5) * 2,
            speedY: (Math.random() - 0.5) * 2,
            intelligence: 0.5 + Math.random() * 0.5 // AI factor
        });
    }
    
    // Create tokens
    for (let i = 0; i < 10; i++) {
        state.tokens.push({
            x: Math.random() * canvas.width,
            y: Math.random() * canvas.height,
            size: 8,
            color: '#eab308',
            value: Math.floor(Math.random() * 10) + 1
        });
    }
    
    // Create obstacles
    for (let i = 0; i < 8; i++) {
        state.obstacles.push({
            x: Math.random() * canvas.width,
            y: Math.random() * canvas.height,
            width: 30 + Math.random() * 50,
            height: 30 + Math.random() * 50,
            color: isDark ? '#1f2937' : '#d1d5db'
        });
    }
    
    // Game loop
    function gameLoop() {
        // Clear canvas
        ctx.fillStyle = isDark ? '#374151' : '#f3f4f6';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        
        // Update frame counter
        state.frame++;
        
        // Draw obstacles
        state.obstacles.forEach(obstacle => {
            ctx.fillStyle = obstacle.color;
            ctx.fillRect(obstacle.x, obstacle.y, obstacle.width, obstacle.height);
        });
        
        // Draw tokens
        state.tokens.forEach(token => {
            ctx.fillStyle = token.color;
            ctx.beginPath();
            ctx.arc(token.x, token.y, token.size, 0, Math.PI * 2);
            ctx.fill();
            
            // Token value
            ctx.fillStyle = isDark ? '#f3f4f6' : '#1f2937';
            ctx.font = '10px Arial';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(token.value, token.x, token.y);
        });