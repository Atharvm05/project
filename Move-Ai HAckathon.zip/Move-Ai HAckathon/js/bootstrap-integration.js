// Bootstrap Integration

document.addEventListener('DOMContentLoaded', function() {
    // Add Bootstrap JavaScript via CDN if not already loaded
    if (typeof bootstrap === 'undefined') {
        const bootstrapScript = document.createElement('script');
        bootstrapScript.src = 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js';
        bootstrapScript.integrity = 'sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz';
        bootstrapScript.crossOrigin = 'anonymous';
        document.head.appendChild(bootstrapScript);
        
        // Initialize components after script is loaded
        bootstrapScript.onload = function() {
            initBootstrapComponents();
        };
    } else {
        // Bootstrap is already loaded, initialize components immediately
        initBootstrapComponents();
    }
    
    // Initialize Bootstrap tooltips and popovers when Bootstrap is loaded
    const initBootstrapComponents = function() {
        // Initialize tooltips
        const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        tooltipTriggerList.map(function(tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
        
        // Initialize popovers
        const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
        popoverTriggerList.map(function(popoverTriggerEl) {
            return new bootstrap.Popover(popoverTriggerEl);
        });
        
        // Initialize dropdowns
        const dropdownElementList = [].slice.call(document.querySelectorAll('.dropdown-toggle'));
        dropdownElementList.map(function(dropdownToggleEl) {
            return new bootstrap.Dropdown(dropdownToggleEl);
        });
        
        // Initialize modals
        const modalElementList = [].slice.call(document.querySelectorAll('.modal'));
        modalElementList.map(function(modalEl) {
            return new bootstrap.Modal(modalEl);
        });
        
        // Initialize toasts
        const toastElementList = [].slice.call(document.querySelectorAll('.toast'));
        toastElementList.map(function(toastEl) {
            return new bootstrap.Toast(toastEl);
        });
    };