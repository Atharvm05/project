// Wallet Connection Implementation

// Wallet connection functionality with comprehensive Aptos wallet support
class WalletConnection {
    constructor() {
        this.connected = false;
        this.address = null;
        this.balance = 0;
        this.network = null;
        this.walletType = null;
        this.aptosClient = null;
        this.transactions = [];
    }
    
    async connect() {
        try {
            // Initialize Aptos client based on network
            await this.initAptosClient('mainnet');
            
            // Check for available wallets
            const wallets = [];
            if (typeof window.aptos !== 'undefined') wallets.push({ type: 'Petra', provider: window.aptos });
            if (typeof window.martian !== 'undefined') wallets.push({ type: 'Martian', provider: window.martian });
            
            if (wallets.length === 0) {
                throw new Error('No compatible wallet found. Please install Petra or Martian wallet.');
            }
            
            // Try connecting to available wallets
            for (const wallet of wallets) {
                try {
                    const response = await wallet.provider.connect();
                    this.connected = true;
                    this.address = response.address;
                    this.network = await wallet.provider.network();
                    this.walletType = wallet.type;
                    
                    // Get balance
                    const balanceResponse = await this.getBalance(this.address);
                    this.balance = balanceResponse;
                    
                    // Load transaction history
                    await this.loadTransactionHistory();
                    
                    return {
                        success: true,
                        address: this.address,
                        balance: this.balance,
                        network: this.network,
                        walletType: this.walletType
                    };
                } catch (walletError) {
                    console.warn(`Error connecting to ${wallet.type} wallet:`, walletError);
                    continue;
                }
            }
            
            throw new Error('Failed to connect to any available wallet. Please try again.')
            } 
            // Check for Martian wallet
            else if (typeof window.martian !== 'undefined') {
                try {
                    // Connect to Martian wallet
                    const response = await window.martian.connect();
                    this.connected = true;
                    this.address = response.address;
                    this.network = await window.martian.network();
                    this.walletType = 'Martian';
                    
                    // Get balance
                    const balanceResponse = await this.getBalance(this.address);
                    this.balance = balanceResponse;
                    
                    // Load transaction history
                    await this.loadTransactionHistory();
                    
                    return {
                        success: true,
                        address: this.address,
                        balance: this.balance,
                        network: this.network,
                        walletType: this.walletType
                    };
                } catch (error) {
                    console.error('Error connecting to Martian wallet:', error);
                    return { success: false, error: error.message };
                }
            }
            // Check for Pontem wallet
            else if (typeof window.pontem !== 'undefined') {
                try {
                    // Connect to Pontem wallet
                    const response = await window.pontem.connect();
                    this.connected = true;
                    this.address = response.address;
                    this.network = await window.pontem.network();
                    this.walletType = 'Pontem';
                    
                    // Get balance
                    const balanceResponse = await this.getBalance(this.address);
                    this.balance = balanceResponse;
                    
                    // Load transaction history
                    await this.loadTransactionHistory();
                    
                    return {
                        success: true,
                        address: this.address,
                        balance: this.balance,
                        network: this.network,
                        walletType: this.walletType
                    };
                } catch (error) {
                    console.error('Error connecting to Pontem wallet:', error);
                    return { success: false, error: error.message };
                }
            }
            // Check for Rise wallet
            else if (typeof window.rise !== 'undefined') {
                try {
                    // Connect to Rise wallet
                    const response = await window.rise.connect();
                    this.connected = true;
                    this.address = response.address;
                    this.network = await window.rise.network();
                    this.walletType = 'Rise';
                    
                    // Get balance
                    const balanceResponse = await this.getBalance(this.address);
                    this.balance = balanceResponse;
                    
                    // Load transaction history
                    await this.loadTransactionHistory();
                    
                    return {
                        success: true,
                        address: this.address,
                        balance: this.balance,
                        network: this.network,
                        walletType: this.walletType
                    };
                } catch (error) {
                    console.error('Error connecting to Rise wallet:', error);
                    return { success: false, error: error.message };
                }
            } else {
                // Mock connection for demo purposes
                this.connected = true;
                this.address = '0x' + Array(64).fill(0).map(() => Math.floor(Math.random() * 16).toString(16)).join('');
                this.balance = Math.floor(Math.random() * 10000) / 100;
                this.network = 'testnet';
                this.walletType = 'Demo';
                
                // Generate mock transaction history
                this.generateMockTransactions();
                
                return {
                    success: true,
                    address: this.address,
                    balance: this.balance,
                    network: this.network,
                    walletType: this.walletType,
                    mock: true
                };
            }
        } catch (error) {
            console.error('Unexpected error during wallet connection:', error);
            return { success: false, error: 'Failed to connect wallet: ' + error.message };
        }
    }
    
    async disconnect() {
        // Simulate disconnection delay
        await new Promise(resolve => setTimeout(resolve, 500));
        
        if (this.walletType === 'Petra' && typeof window.aptos !== 'undefined') {
            try {
                // Disconnect from Petra wallet
                await window.aptos.disconnect();
            } catch (error) {
                console.error('Error disconnecting from Petra wallet:', error);
            }
        } else if (this.walletType === 'Martian' && typeof window.martian !== 'undefined') {
            try {
                // Disconnect from Martian wallet
                await window.martian.disconnect();
            } catch (error) {
                console.error('Error disconnecting from Martian wallet:', error);
            }
        }
        
        this.connected = false;
        this.address = null;
        this.balance = 0;
        this.network = null;
        this.walletType = null;
        
        return { success: true };
    }
    
    async getBalance(address) {
        try {
            if (this.walletType === 'Petra' && typeof window.aptos !== 'undefined') {
                try {
                    // Get balance from Petra wallet
                    const resources = await window.aptos.getAccountResources(address);
                    const aptosCoin = resources.find(r => r.type === '0x1::coin::CoinStore<0x1::aptos_coin::AptosCoin>');
                    return aptosCoin ? parseInt(aptosCoin.data.coin.value) / 100000000 : 0;
                } catch (error) {
                    console.error('Error getting balance from Petra wallet:', error);
                    return 0;
                }
            } else if (this.walletType === 'Martian' && typeof window.martian !== 'undefined') {
                try {
                    // Get balance from Martian wallet
                    const resources = await window.martian.getAccountResources(address);
                    const aptosCoin = resources.find(r => r.type === '0x1::coin::CoinStore<0x1::aptos_coin::AptosCoin>');
                    return aptosCoin ? parseInt(aptosCoin.data.coin.value) / 100000000 : 0;
                } catch (error) {
                    console.error('Error getting balance from Martian wallet:', error);
                    return 0;
                }
            } else if (this.walletType === 'Pontem' && typeof window.pontem !== 'undefined') {
                try {
                    // Get balance from Pontem wallet
                    const resources = await window.pontem.getAccountResources(address);
                    const aptosCoin = resources.find(r => r.type === '0x1::coin::CoinStore<0x1::aptos_coin::AptosCoin>');
                    return aptosCoin ? parseInt(aptosCoin.data.coin.value) / 100000000 : 0;
                } catch (error) {
                    console.error('Error getting balance from Pontem wallet:', error);
                    return 0;
                }
            } else if (this.walletType === 'Rise' && typeof window.rise !== 'undefined') {
                try {
                    // Get balance from Rise wallet
                    const resources = await window.rise.getAccountResources(address);
                    const aptosCoin = resources.find(r => r.type === '0x1::coin::CoinStore<0x1::aptos_coin::AptosCoin>');
                    return aptosCoin ? parseInt(aptosCoin.data.coin.value) / 100000000 : 0;
                } catch (error) {
                    console.error('Error getting balance from Rise wallet:', error);
                    return 0;
                }
            } else if (this.aptosClient && address) {
                try {
                    // Get balance using Aptos client for any wallet
                    const resources = await this.aptosClient.getAccountResources(address);
                    const aptosCoin = resources.find(r => r.type === '0x1::coin::CoinStore<0x1::aptos_coin::AptosCoin>');
                    return aptosCoin ? parseInt(aptosCoin.data.coin.value) / 100000000 : 0;
                } catch (error) {
                    console.error('Error getting balance from Aptos client:', error);
                    return 0;
                }
            } else {
                // If no wallet is available or for demo mode, return mock balance
                return this.balance;
            }
        } catch (error) {
            console.error('Unexpected error getting balance:', error);
            return 0;
        }
    }
    
    // Initialize Aptos client
    initAptosClient(network = 'testnet') {
        // In a real implementation, we would initialize the Aptos client here
        // For demo purposes, we'll just set a flag
        this.aptosClient = {
            network: network,
            getAccountResources: async (address) => {
                // Mock implementation for demo
                await new Promise(resolve => setTimeout(resolve, 500));
                return [{
                    type: '0x1::coin::CoinStore<0x1::aptos_coin::AptosCoin>',
                    data: { coin: { value: String(this.balance * 100000000) } }
                }];
            },
            getAccountTransactions: async (address) => {
                // Mock implementation for demo
                await new Promise(resolve => setTimeout(resolve, 500));
                return this.transactions;
            }
        };
    }
    
    // Load transaction history
    async loadTransactionHistory() {
        try {
            if (!this.address) return;
            
            if (this.walletType === 'Demo') {
                // For demo mode, we already generated mock transactions
                return;
            }
            
            // In a real implementation, we would fetch transaction history from the blockchain
            // For now, we'll use the Aptos client mock
            if (this.aptosClient) {
                const txns = await this.aptosClient.getAccountTransactions(this.address);
                this.transactions = txns;
            }
        } catch (error) {
            console.error('Error loading transaction history:', error);
        }
    }
    
    // Generate mock transactions for demo
    generateMockTransactions() {
        const txTypes = ['send', 'receive', 'swap', 'stake'];
        const tokens = ['APT', 'BTC', 'ETH', 'USDC', 'USDT'];
        
        // Generate 5-10 random transactions
        const count = 5 + Math.floor(Math.random() * 6);
        const now = Date.now();
        
        this.transactions = [];
        
        for (let i = 0; i < count; i++) {
            const type = txTypes[Math.floor(Math.random() * txTypes.length)];
            const token1 = tokens[Math.floor(Math.random() * tokens.length)];
            let token2 = tokens[Math.floor(Math.random() * tokens.length)];
            while (token2 === token1 && type === 'swap') {
                token2 = tokens[Math.floor(Math.random() * tokens.length)];
            }
            
            const amount1 = Math.floor(Math.random() * 1000) / 10;
            const amount2 = Math.floor(Math.random() * 1000) / 10;
            
            const timestamp = new Date(now - Math.floor(Math.random() * 7 * 24 * 60 * 60 * 1000));
            
            let description = '';
            let otherAddress = '0x' + Array(64).fill(0).map(() => Math.floor(Math.random() * 16).toString(16)).join('');
            
            switch (type) {
                case 'send':
                    description = `Sent ${amount1} ${token1} to ${otherAddress.substring(0, 10)}...`;
                    break;
                case 'receive':
                    description = `Received ${amount1} ${token1} from ${otherAddress.substring(0, 10)}...`;
                    break;
                case 'swap':
                    description = `Swapped ${amount1} ${token1} for ${amount2} ${token2}`;
                    break;
                case 'stake':
                    description = `Staked ${amount1} ${token1}`;
                    break;
            }
            
            this.transactions.push({
                type,
                description,
                amount1,
                token1,
                amount2: type === 'swap' ? amount2 : null,
                token2: type === 'swap' ? token2 : null,
                timestamp,
                hash: '0x' + Array(64).fill(0).map(() => Math.floor(Math.random() * 16).toString(16)).join(''),
                status: Math.random() > 0.1 ? 'confirmed' : 'pending'
            });
        }
        
        // Sort by timestamp (newest first)
        this.transactions.sort((a, b) => b.timestamp - a.timestamp);
    }
    
    // Execute a transaction
    async executeTransaction(txData) {
        try {
            if (!this.connected) {
                throw new Error('Wallet not connected');
            }
            
            // Show loading notification
            this.showNotification('Processing transaction...', 'info');
            
            // Simulate transaction delay
            await new Promise(resolve => setTimeout(resolve, 2000));
            
            if (this.walletType === 'Petra' && typeof window.aptos !== 'undefined') {
                // Execute transaction with Petra wallet
                // In a real implementation, we would use the actual wallet API
                // For demo, we'll just simulate success
                const result = { success: true, hash: '0x' + Array(64).fill(0).map(() => Math.floor(Math.random() * 16).toString(16)).join('') };
                
                // Add to transaction history
                const newTx = {
                    type: txData.type,
                    description: txData.description,
                    amount1: txData.amount,
                    token1: txData.token,
                    timestamp: new Date(),
                    hash: result.hash,
                    status: 'confirmed'
                };
                
                this.transactions.unshift(newTx);
                
                // Update balance if needed
                if (txData.type === 'send') {
                    this.balance -= txData.amount;
                } else if (txData.type === 'receive') {
                    this.balance += txData.amount;
                }
                
                // Show success notification
                this.showNotification('Transaction successful!', 'success');
                
                return { success: true, hash: result.hash };
            } else {
                // For demo mode or other wallets
                const result = { success: true, hash: '0x' + Array(64).fill(0).map(() => Math.floor(Math.random() * 16).toString(16)).join('') };
                
                // Add to transaction history
                const newTx = {
                    type: txData.type,
                    description: txData.description,
                    amount1: txData.amount,
                    token1: txData.token,
                    timestamp: new Date(),
                    hash: result.hash,
                    status: 'confirmed'
                };
                
                this.transactions.unshift(newTx);
                
                // Update balance if needed
                if (txData.type === 'send') {
                    this.balance -= txData.amount;
                } else if (txData.type === 'receive') {
                    this.balance += txData.amount;
                }
                
                // Show success notification
                this.showNotification('Transaction successful!', 'success');
                
                return { success: true, hash: result.hash };
            }
        } catch (error) {
            console.error('Error executing transaction:', error);
            
            // Show error notification
            this.showNotification('Transaction failed: ' + error.message, 'error');
            
            return { success: false, error: error.message };
        }
    }
    
    // Show notification
    showNotification(message, type = 'info') {
        // Remove existing notification if present
        const existingNotification = document.getElementById('wallet-notification');
        if (existingNotification) {
            existingNotification.remove();
        }
        
        // Create notification element
        const notification = document.createElement('div');
        notification.id = 'wallet-notification';
        notification.className = `fixed bottom-4 right-4 p-4 rounded-lg shadow-lg z-50 flex items-center ${type === 'success' ? 'bg-green-500' : type === 'error' ? 'bg-red-500' : 'bg-blue-500'} text-white`;
        
        // Add icon based on type
        let icon = 'info-circle';
        if (type === 'success') icon = 'check-circle';
        if (type === 'error') icon = 'exclamation-circle';
        
        notification.innerHTML = `
            <i class="fas fa-${icon} mr-2"></i>
            <span>${message}</span>
            <button class="ml-4 text-white hover:text-gray-200">
                <i class="fas fa-times"></i>
            </button>
        `;
        
        // Add to body
        document.body.appendChild(notification);
        
        // Add close button functionality
        const closeButton = notification.querySelector('button');
        closeButton.addEventListener('click', function() {
            notification.remove();
        });
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            if (document.body.contains(notification)) {
                notification.remove();
            }
        }, 5000);
    }
    
    isConnected() {
        return this.connected;
    }
    
    getAddress() {
        return this.address;
    }
    
    getNetwork() {
        return this.network;
    }
    
    getTransactions() {
        return this.transactions;
    }
}

// Global wallet instance
const wallet = new WalletConnection();

// Initialize wallet connection UI
function initWalletConnection() {
    const connectButtons = document.querySelectorAll('.bg-indigo-600.text-white');
    
    // Update button styles based on theme
    function updateButtonStyles(isDark) {
        connectButtons.forEach(button => {
            button.className = `${isDark ? 'dark' : ''} bg-indigo-600 hover:bg-indigo-700 dark:bg-indigo-500 dark:hover:bg-indigo-600 text-white px-4 py-2 rounded-lg transition-colors duration-200`;
        });
    }
    
    // Listen for theme changes
    window.addEventListener('themeChange', (e) => {
        updateButtonStyles(e.detail.isDark);
    });
    
    // Initial theme setup
    updateButtonStyles(document.documentElement.classList.contains('dark'));
    
    connectButtons.forEach(button => {
        if (button.textContent.includes('Connect Wallet')) {
            button.addEventListener('click', async function() {
                if (!wallet.isConnected()) {
                    try {
                        // Show loading state
                        const originalText = button.textContent;
                        button.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Connecting...';
                        button.disabled = true;
                        
                        // Connect wallet
                        const result = await wallet.connect();
                        
                        if (result.success) {
                            // Update button text
                            button.innerHTML = '<i class="fas fa-wallet mr-2"></i> Disconnect';
                            button.disabled = false;
                            
                            // Create wallet info display
                            createWalletInfoDisplay(result);
                            
                            // Dispatch wallet connection event
                            window.dispatchEvent(new CustomEvent('walletConnected', { detail: result }));
                        } else {
                            throw new Error(result.error || 'Unknown error');
                        }
                    } catch (error) {
                        // Show error in a more user-friendly way
                        button.innerHTML = originalText;
                        button.disabled = false;
                        
                        const errorModal = document.createElement('div');
                        errorModal.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
                        errorModal.innerHTML = `
                            <div class="bg-white dark:bg-gray-800 rounded-lg p-6 max-w-sm mx-4">
                                <h3 class="text-lg font-semibold text-gray-800 dark:text-white mb-2">Connection Failed</h3>
                                <p class="text-gray-600 dark:text-gray-400 mb-4">${error.message}</p>
                                <button class="w-full bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg transition-colors duration-200">Close</button>
                            </div>
                        `;
                        
                        document.body.appendChild(errorModal);
                        
                        const closeButton = errorModal.querySelector('button');
                        closeButton.addEventListener('click', () => errorModal.remove());
                        errorModal.addEventListener('click', (e) => {
                            if (e.target === errorModal) errorModal.remove();
                        });
                    }
                } else {
                    try {
                        // Show loading state
                        button.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Disconnecting...';
                        button.disabled = true;
                        
                        // Disconnect wallet
                        const result = await wallet.disconnect();
                        
                        // Update button text
                        button.innerHTML = 'Connect Wallet';
                        button.disabled = false;
                        
                        // Remove wallet info display
                        removeWalletInfoDisplay();
                        
                        // Dispatch wallet disconnection event
                        window.dispatchEvent(new CustomEvent('walletDisconnected'));
                    } catch (error) {
                        console.error('Error disconnecting wallet:', error);
                        button.disabled = false;
                        button.innerHTML = '<i class="fas fa-wallet mr-2"></i> Disconnect';
                    }
                }
            });
        }
    });
}
}

// Create wallet info display
function createWalletInfoDisplay(walletData) {
    // Remove existing display if any
    removeWalletInfoDisplay();
    
    // Create wallet info container
    const walletInfo = document.createElement('div');
    walletInfo.id = 'wallet-info';
    walletInfo.className = 'fixed top-20 right-4 bg-white dark:bg-gray-800 p-4 rounded-lg shadow-lg z-50 max-w-sm';
    
    // Add wallet info content
    walletInfo.innerHTML = `
        <div class="flex justify-between items-center mb-3">
            <h3 class="text-lg font-semibold text-gray-800 dark:text-white">Wallet Connected</h3>
            <button id="close-wallet-info" class="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <div class="space-y-2">
            <div class="flex items-center">
                <div class="w-4 h-4 rounded-full bg-green-500 mr-2"></div>
                <span class="text-sm text-gray-600 dark:text-gray-400">${walletData.network || 'Unknown'} Network</span>
            </div>
            <div>
                <p class="text-sm text-gray-600 dark:text-gray-400">Address:</p>
                <p class="text-xs bg-gray-100 dark:bg-gray-700 p-2 rounded overflow-x-auto">${walletData.address}</p>
            </div>
            <div>
                <p class="text-sm text-gray-600 dark:text-gray-400">Balance:</p>
                <p class="text-lg font-semibold text-indigo-600 dark:text-indigo-400">${walletData.balance} APT</p>
            </div>
        </div>
    `;
    
    // Add wallet info to body
    document.body.appendChild(walletInfo);
    
    // Add close button event listener
    document.getElementById('close-wallet-info').addEventListener('click', function() {
        removeWalletInfoDisplay();
    });
}

// Remove wallet info display
function removeWalletInfoDisplay() {
    const walletInfo = document.getElementById('wallet-info');
    if (walletInfo) {
        walletInfo.remove();
    }
}

// Initialize wallet connection when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initWalletConnection();
});