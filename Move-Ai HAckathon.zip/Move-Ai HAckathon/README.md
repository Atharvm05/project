# Aptos AI Nexus

A revolutionary Multi-Agent AI Ecosystem built on the Aptos blockchain, combining DeFi, Social AI, and GameFi capabilities.

## Features

- **Dark Mode Support**: Seamless theme switching with system preference detection
- **Multi-Wallet Integration**: Support for Petra and Martian wallets
- **DeFi AI Integration**: Portfolio management and performance tracking
- **Social AI Features**: Cross-platform sentiment analysis
- **GameFi Elements**: Interactive AI-driven gaming experiences
- **Responsive Design**: Mobile-first approach with modern UI/UX

## Getting Started

### Prerequisites

- Modern web browser (Chrome, Firefox, Safari)
- Aptos wallet (Petra or Martian)

### Installation

1. Clone the repository
2. Open `index.html` in your browser
3. Connect your Aptos wallet

### Wallet Connection

1. Click the "Connect Wallet" button in the navigation bar
2. Select your preferred wallet (Petra or Martian)
3. Approve the connection request

## Features Usage

### Dark Mode

- Click the moon/sun icon in the navigation bar to toggle between light and dark modes
- System preference detection automatically sets initial theme

### DeFi Features

- View portfolio performance in the DeFi section
- Track historical performance against benchmarks
- Analyze AI-driven investment suggestions

### Social AI

- Monitor cross-platform sentiment analysis
- Track community engagement metrics
- View trending topics and discussions

### GameFi

- Interact with AI-driven NPCs
- Participate in blockchain-based gaming experiences
- Track gaming achievements and rewards

## Development

### Project Structure

```
/
├── css/
│   ├── styles.css
│   └── responsive.css
├── js/
│   ├── main.js
│   ├── wallet-connection.js
│   └── wallet-ui.js
├── images/
└── index.html
```

### Key Components

- `main.js`: Core functionality and dark mode implementation
- `wallet-connection.js`: Wallet integration and management
- `wallet-ui.js`: UI components for wallet interaction

## Contributing

1. Fork the repository
2. Create your feature branch
3. Commit your changes
4. Push to the branch
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.